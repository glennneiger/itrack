#!/usr/bin/php
cd /weekly_report_ln/plant_distance/mumbai
php mail_distance_report.php


