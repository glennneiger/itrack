#!/usr/bin/php
cd /weekly_report_ln/plant_distance/ice_cream
php mail_distance_report.php


