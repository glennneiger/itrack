#!/usr/bin/php
cd /weekly_report_ln/plant_distance/delhi
php mail_distance_report.php


