#!/usr/bin/php
cd /weekly_report_ln/plant_distance/tanker
php mail_distance_report.php


