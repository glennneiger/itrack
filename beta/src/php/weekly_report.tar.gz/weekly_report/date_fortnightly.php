<?php
$previous_date = "2013-09-01";
$current_date = "2013-09-15";
//$previous_date = "2013-08-16";
//$current_date = "2013-08-31";

?>
